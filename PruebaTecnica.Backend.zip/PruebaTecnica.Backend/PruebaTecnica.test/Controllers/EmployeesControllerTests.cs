using Microsoft.AspNetCore.Mvc;
using Moq;
using PruebaTecnica.Api.Controllers;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Tests.Controllers
{
    [TestClass]
    public class EmployeesControllerTests
    {
        [TestMethod]
        public void Constructor_SetsLookupService()
        {
            // Arrange
            var mockLookup = new Mock<ILookupService>();

            // Act
            var controller = new EmployeesController(mockLookup.Object);

            // Assert
            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public async Task Get_ReturnsOkWithEmployees()
        {
            // Arrange
            var employees = new List<EmployeeDto>
            {
                new(1, "Juan P�rez") 
            };
            var mockLookup = new Mock<ILookupService>();
            mockLookup.Setup(x => x.GetEmployeesAsync()).ReturnsAsync(employees);

            var controller = new EmployeesController(mockLookup.Object);

            // Act
            var result = await controller.Get();

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode ?? 200);
            Assert.AreEqual(employees, okResult.Value);
            mockLookup.Verify(x => x.GetEmployeesAsync(), Times.Once);
        }

        [TestMethod]
        public async Task Get_ReturnsOkWithEmptyList()
        {
            // Arrange
            var employees = new List<EmployeeDto>();
            var mockLookup = new Mock<ILookupService>();
            mockLookup.Setup(x => x.GetEmployeesAsync()).ReturnsAsync(employees);

            var controller = new EmployeesController(mockLookup.Object);

            // Act
            var result = await controller.Get();

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode ?? 200);
            Assert.AreEqual(employees, okResult.Value);
            mockLookup.Verify(x => x.GetEmployeesAsync(), Times.Once);
        }
    }
}
