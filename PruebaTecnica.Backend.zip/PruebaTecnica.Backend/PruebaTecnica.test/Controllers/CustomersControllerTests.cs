using Microsoft.AspNetCore.Mvc;
using Moq;
using PruebaTecnica.Api.Controllers;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Tests.Controllers
{
    [TestClass]
    public class CustomersControllerTests
    {
        [TestMethod]
        public void Constructor_SetsLookupService()
        {
            // Arrange
            var mockLookup = new Mock<ILookupService>();

            // Act
            var controller = new CustomersController(mockLookup.Object);

            // Assert
            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public async Task GetOrdersByCustomer_ReturnsOkWithOrders()
        {
            // Arrange
            var customerId = 1;
            var orders = new List<OrderSummaryDto>
            {
                new(OrderId: 10, RequiredDate: System.DateTime.UtcNow, ShippedDate: System.DateTime.UtcNow, 
                ShipName: "Test Ship", ShipAddress: "Test Address", ShipCity: "Test City")
            };
            var mockLookup = new Mock<ILookupService>();
            mockLookup.Setup(x => x.GetOrdersByCustomerAsync(customerId)).ReturnsAsync(orders);

            var controller = new CustomersController(mockLookup.Object);

            // Act
            var result = await controller.GetOrdersByCustomer(customerId);

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode ?? 200);
            Assert.AreEqual(orders, okResult.Value);
            mockLookup.Verify(x => x.GetOrdersByCustomerAsync(customerId), Times.Once);
        }

        [TestMethod]
        public async Task GetOrdersByCustomer_ReturnsOkWithEmptyList()
        {
            // Arrange
            var customerId = 2;
            var orders = new List<OrderSummaryDto>();
            var mockLookup = new Mock<ILookupService>();
            mockLookup.Setup(x => x.GetOrdersByCustomerAsync(customerId)).ReturnsAsync(orders);

            var controller = new CustomersController(mockLookup.Object);

            // Act
            var result = await controller.GetOrdersByCustomer(customerId);

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode ?? 200);
            Assert.AreEqual(orders, okResult.Value);
            mockLookup.Verify(x => x.GetOrdersByCustomerAsync(customerId), Times.Once);
        }
    }
}
