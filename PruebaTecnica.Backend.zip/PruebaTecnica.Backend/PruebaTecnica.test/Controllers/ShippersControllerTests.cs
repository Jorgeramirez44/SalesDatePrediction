using Microsoft.AspNetCore.Mvc;
using Moq;
using PruebaTecnica.Api.Controllers;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Tests.Controllers
{
    [TestClass]
    public class ShippersControllerTests
    {
        [TestMethod]
        public void Constructor_SetsLookupService()
        {
            // Arrange
            var mockLookupService = new Mock<ILookupService>();

            // Act
            var controller = new ShippersController(mockLookupService.Object);

            // Assert
            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public async Task Get_ReturnsOkWithShippers()
        {
            // Arrange
            var mockLookupService = new Mock<ILookupService>();
            var shippers = new List<ShipperDto>
            {
                new (1, "Transporte 1" ),
                new (2, "Transporte 2")
            };
            mockLookupService.Setup(x => x.GetShippersAsync()).ReturnsAsync(shippers);

            var controller = new ShippersController(mockLookupService.Object);

            // Act
            var result = await controller.Get();

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(shippers, okResult.Value);
            mockLookupService.Verify(x => x.GetShippersAsync(), Times.Once);
        }
    }
}