using Microsoft.AspNetCore.Mvc;
using Moq;
using PruebaTecnica.Api.Controllers;
using PruebaTecnica.Application.Common;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Tests.Controllers
{
    [TestClass]
    public class PredictionsControllerTests
    {
        [TestMethod]
        public void Constructor_SetsPredictionService()
        {
            // Arrange
            var mockPredictionService = new Mock<IPredictionService>();

            // Act
            var controller = new PredictionsController(mockPredictionService.Object);

            // Assert
            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public async Task GetCustomerPredictions_ReturnsOkWithResult()
        {
            // Arrange
            var mockPredictionService = new Mock<IPredictionService>();
            var pagedResult = new PagedResult<PredictionItemDto>(
                new List<PredictionItemDto>
                {
                                    new PredictionItemDto
                                    (
                                         1,
                                        "Cliente 1",
                                        null,
                                        null,
                                        0,
                                        null
                                    ),
                               new PredictionItemDto
                                    (
                                         2,
                                        "Cliente 2",
                                        null,
                                        null,
                                        0,
                                        null
                                    )
                },
                2, // TotalCount
                1, // PageNumber
                20 // PageSize
            );
            mockPredictionService
                .Setup(x => x.GetCustomerPredictionsAsync("busqueda", 1, 20, "name"))
                .ReturnsAsync(pagedResult);

            var controller = new PredictionsController(mockPredictionService.Object);

            // Act
            var result = await controller.GetCustomerPredictions("busqueda", 1, 20, "name");

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(pagedResult, okResult.Value);
            mockPredictionService.Verify(x => x.GetCustomerPredictionsAsync("busqueda", 1, 20, "name"), Times.Once);
        }
    }
}



