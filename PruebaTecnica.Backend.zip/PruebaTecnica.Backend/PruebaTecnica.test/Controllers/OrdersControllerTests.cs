using Microsoft.AspNetCore.Mvc;
using Moq;
using PruebaTecnica.Api.Controllers;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Tests.Controllers
{
    [TestClass]
    public class OrdersControllerTests
    {
        [TestMethod]
        public void Constructor_SetsOrderService()
        {
            // Arrange
            var mockOrderService = new Mock<IOrderService>();

            // Act
            var controller = new OrdersController(mockOrderService.Object);

            // Assert
            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public async Task Create_ValidModel_ReturnsCreatedAtAction()
        {
            // Arrange
            var mockOrderService = new Mock<IOrderService>();
            var request = new CreateOrderRequestDto
            {
                CustId = 1,
                EmpId = 2,
                ShipperId = 3,
                ShipName = "Barco",
                ShipAddress = "Calle 123",
                ShipCity = "Ciudad",
                ShipCountry = "Pa�s",
                OrderDate = System.DateTime.UtcNow,
                RequiredDate = System.DateTime.UtcNow.AddDays(1),
                Freight = 10,
                Detail = new CreateOrderDetailDto
                {
                    ProductId = 1,
                    UnitPrice = 100,
                    Qty = 2,
                    Discount = 0
                }
            };
            int newId = 42;
            mockOrderService.Setup(x => x.CreateOrderWithSingleDetailAsync(request)).ReturnsAsync(newId);

            var controller = new OrdersController(mockOrderService.Object);

            // Act
            var result = await controller.Create(request);

            // Assert
            var createdResult = result as CreatedAtActionResult;
            Assert.IsNotNull(createdResult);
            Assert.AreEqual(nameof(controller.Create), createdResult.ActionName);

            // Acceso robusto al valor retornado usando reflexi�n
            var valueType = createdResult.Value!.GetType();
            var orderIdProperty = valueType.GetProperty("orderId");
            Assert.IsNotNull(orderIdProperty, "El valor retornado debe tener la propiedad 'orderId'");
            var orderIdValue = orderIdProperty.GetValue(createdResult.Value);
            Assert.AreEqual(newId, orderIdValue);

            Assert.AreEqual(newId, createdResult?.RouteValues?["id"]);
            mockOrderService.Verify(x => x.CreateOrderWithSingleDetailAsync(request), Times.Once);
        }


        [TestMethod]
        public async Task Create_InvalidModel_ReturnsValidationProblem()
        {
            // Arrange
            var mockOrderService = new Mock<IOrderService>();
            var request = new CreateOrderRequestDto(); // Campos requeridos vac�os
            var controller = new OrdersController(mockOrderService.Object);
            controller.ModelState.AddModelError("CustId", "Requerido");

            // Act
            var result = await controller.Create(request);

            // Assert
            var objectResult = result as ObjectResult;
            Assert.IsNotNull(objectResult, "El resultado debe ser ObjectResult");
            
            Assert.IsTrue(objectResult.StatusCode == 400 || objectResult.StatusCode == null, "El c�digo de estado debe ser 400 o nulo");
            var problemDetails = objectResult.Value as ValidationProblemDetails;
            Assert.IsNotNull(problemDetails, "El valor debe ser ValidationProblemDetails");
            Assert.IsTrue(problemDetails.Errors.ContainsKey("CustId"), "Debe contener el error de CustId");
            Assert.IsTrue(problemDetails.Errors["CustId"].Any(e => e.Contains("Requerido")), "El mensaje de error debe ser 'Requerido'");

            mockOrderService.Verify(x => x.CreateOrderWithSingleDetailAsync(It.IsAny<CreateOrderRequestDto>()), Times.Never);
        }


    }
}
