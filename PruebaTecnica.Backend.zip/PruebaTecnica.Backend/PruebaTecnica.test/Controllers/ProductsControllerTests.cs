using Microsoft.AspNetCore.Mvc;
using Moq;
using PruebaTecnica.Api.Controllers;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Tests.Controllers
{
    [TestClass]
    public class ProductsControllerTests
    {
        [TestMethod]
        public void Constructor_SetsLookupService()
        {
            // Arrange
            var mockLookupService = new Mock<ILookupService>();

            // Act
            var controller = new ProductsController(mockLookupService.Object);

            // Assert
            Assert.IsNotNull(controller);
        }

        [TestMethod]
        public async Task Get_ReturnsOkWithProducts()
        {
            // Arrange
            var mockLookupService = new Mock<ILookupService>();
            var products = new List<ProductDto>
            {
                new ( 1, "Producto 1" ),
                new ( 2, "Producto 2" )                
            };
            mockLookupService.Setup(x => x.GetProductsAsync()).ReturnsAsync(products);

            var controller = new ProductsController(mockLookupService.Object);

            // Act
            var result = await controller.Get();

            // Assert
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(products, okResult.Value);
            mockLookupService.Verify(x => x.GetProductsAsync(), Times.Once);
        }
    }
}

