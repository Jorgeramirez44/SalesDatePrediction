using Microsoft.VisualStudio.TestTools.UnitTesting;
using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Tests.DTOs
{
    [TestClass]
    public class EmployeeDtoTests
    {
        [TestMethod]
        public void Constructor_SetsProperties()
        {
            var dto = new EmployeeDto(1, "Juan P�rez");
            Assert.AreEqual(1, dto.EmpId);
            Assert.AreEqual("Juan P�rez", dto.FullName);
        }

        [TestMethod]
        public void Equality_SameValues_ReturnsTrue()
        {
            var dto1 = new EmployeeDto(1, "Juan P�rez");
            var dto2 = new EmployeeDto(1, "Juan P�rez");
            Assert.AreEqual(dto1, dto2);
            Assert.IsTrue(dto1 == dto2);
        }

        [TestMethod]
        public void Equality_DifferentValues_ReturnsFalse()
        {
            var dto1 = new EmployeeDto(1, "Juan P�rez");
            var dto2 = new EmployeeDto(2, "Ana L�pez");
            Assert.AreNotEqual(dto1, dto2);
            Assert.IsTrue(dto1 != dto2);
        }

        [TestMethod]
        public void ToString_ReturnsExpectedFormat()
        {
            var dto = new EmployeeDto(1, "Juan P�rez");
            var str = dto.ToString();
            Assert.IsTrue(str.Contains("EmpId = 1"));
            Assert.IsTrue(str.Contains("FullName = Juan P�rez"));
        }
    }
}
