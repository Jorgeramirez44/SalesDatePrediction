using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Tests.DTOs
{
    [TestClass]
    public class ShipperDtoTests
    {
        [TestMethod]
        public void Constructor_SetsProperties()
        {
            var dto = new ShipperDto(1, "Transporte 1");
            Assert.AreEqual(1, dto.ShipperId);
            Assert.AreEqual("Transporte 1", dto.CompanyName);
        }

        [TestMethod]
        public void Equality_SameValues_ReturnsTrue()
        {
            var dto1 = new ShipperDto(1, "Transporte 1");
            var dto2 = new ShipperDto(1, "Transporte 1");
            Assert.AreEqual(dto1, dto2);
            Assert.IsTrue(dto1 == dto2);
        }

        [TestMethod]
        public void Equality_DifferentValues_ReturnsFalse()
        {
            var dto1 = new ShipperDto(1, "Transporte 1");
            var dto2 = new ShipperDto(2, "Transporte 2");
            Assert.AreNotEqual(dto1, dto2);
            Assert.IsTrue(dto1 != dto2);
        }

        [TestMethod]
        public void ToString_ReturnsExpectedFormat()
        {
            var dto = new ShipperDto(1, "Transporte 1");
            var str = dto.ToString();
            Assert.IsTrue(str.Contains("ShipperId = 1"));
            Assert.IsTrue(str.Contains("CompanyName = Transporte 1"));
        }
    }
}
