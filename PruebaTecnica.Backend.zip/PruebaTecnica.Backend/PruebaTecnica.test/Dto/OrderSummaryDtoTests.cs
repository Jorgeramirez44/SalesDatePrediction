using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Tests.DTOs
{
    [TestClass]
    public class OrderSummaryDtoTests
    {
        [TestMethod]
        public void Constructor_SetsProperties()
        {
            var requiredDate = new DateTime(2024, 6, 1);
            var shippedDate = new DateTime(2024, 6, 2);
            var dto = new OrderSummaryDto(
                10,
                requiredDate,
                shippedDate,
                "Barco",
                "Calle 123",
                "Ciudad"
            );
            Assert.AreEqual(10, dto.OrderId);
            Assert.AreEqual(requiredDate, dto.RequiredDate);
            Assert.AreEqual(shippedDate, dto.ShippedDate);
            Assert.AreEqual("Barco", dto.ShipName);
            Assert.AreEqual("Calle 123", dto.ShipAddress);
            Assert.AreEqual("Ciudad", dto.ShipCity);
        }

        [TestMethod]
        public void Equality_SameValues_ReturnsTrue()
        {
            var date1 = new DateTime(2024, 6, 1);
            var date2 = new DateTime(2024, 6, 2);
            var dto1 = new OrderSummaryDto(1, date1, date2, "A", "B", "C");
            var dto2 = new OrderSummaryDto(1, date1, date2, "A", "B", "C");
            Assert.AreEqual(dto1, dto2);
            Assert.IsTrue(dto1 == dto2);
        }

        [TestMethod]
        public void Equality_DifferentValues_ReturnsFalse()
        {
            var dto1 = new OrderSummaryDto(1, DateTime.Now, null, "A", "B", "C");
            var dto2 = new OrderSummaryDto(2, DateTime.Now, null, "X", "Y", "Z");
            Assert.AreNotEqual(dto1, dto2);
            Assert.IsTrue(dto1 != dto2);
        }

        [TestMethod]
        public void ToString_ReturnsExpectedFormat()
        {
            var dto = new OrderSummaryDto(1, DateTime.Today, null, "Barco", "Calle 123", "Ciudad");
            var str = dto.ToString();
            Assert.IsTrue(str.Contains("OrderId = 1"));
            Assert.IsTrue(str.Contains("ShipName = Barco"));
            Assert.IsTrue(str.Contains("ShipAddress = Calle 123"));
            Assert.IsTrue(str.Contains("ShipCity = Ciudad"));
        }
    }
}
