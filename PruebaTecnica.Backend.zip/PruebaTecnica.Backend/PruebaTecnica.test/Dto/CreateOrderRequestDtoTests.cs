using PruebaTecnica.Application.DTOs;
using System.ComponentModel.DataAnnotations;

namespace PruebaTecnica.Application.Tests.DTOs
{
    [TestClass]
    public class CreateOrderRequestDtoTests
    {
        [TestMethod]
        public void Constructor_SetsDefaultValues()
        {
            var dto = new CreateOrderRequestDto();
            Assert.AreEqual(string.Empty, dto.ShipName);
            Assert.AreEqual(string.Empty, dto.ShipAddress);
            Assert.AreEqual(string.Empty, dto.ShipCity);
            Assert.AreEqual(string.Empty, dto.ShipCountry);
            Assert.IsNotNull(dto.Detail);
        }

        [TestMethod]
        public void ValidObject_PassesValidation()
        {
            var dto = new CreateOrderRequestDto
            {
                CustId = 1,
                EmpId = 2,
                ShipperId = 3,
                ShipName = "Barco",
                ShipAddress = "Calle 123",
                ShipCity = "Ciudad",
                ShipCountry = "Pa�s",
                OrderDate = DateTime.UtcNow,
                RequiredDate = DateTime.UtcNow.AddDays(1),
                Freight = 10,
                Detail = new CreateOrderDetailDto
                {
                    ProductId = 1,
                    UnitPrice = 100,
                    Qty = 2,
                    Discount = 0
                }
            };
            var context = new ValidationContext(dto);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(dto, context, results, true);
            Assert.IsTrue(isValid);
            Assert.AreEqual(0, results.Count);
        }

        [TestMethod]
        public void InvalidObject_FailsValidation()
        {
            var dto = new CreateOrderRequestDto
            {
                CustId = 0,
                EmpId = 0,
                ShipperId = 0,
                ShipName = new string('A', 41),
                ShipAddress = new string('B', 61),
                ShipCity = new string('C', 16),
                ShipCountry = new string('D', 16),
                OrderDate = default,
                RequiredDate = default,
                Freight = -1,
                Detail = new CreateOrderDetailDto
                {
                    ProductId = 0,
                    UnitPrice = -10, // Fuera de rango
                    Qty = 0, // Fuera de rango
                    Discount = -1 // Fuera de rango
                }
            };
            var context = new ValidationContext(dto);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(dto, context, results, true);
            Assert.IsFalse(isValid);
            Assert.IsTrue(results.Count > 0);
        }

        [TestMethod]
        public void MissingRequiredProperties_FailsValidation()
        {
            var dto = new CreateOrderRequestDto();
            var context = new ValidationContext(dto);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(dto, context, results, true);
            Assert.IsFalse(isValid);
            Assert.IsTrue(results.Count > 0);
        }

        [TestMethod]
        public void CreateOrderDetailDto_ValidObject_PassesValidation()
        {
            var detail = new CreateOrderDetailDto
            {
                ProductId = 1,
                UnitPrice = 10,
                Qty = 1,
                Discount = 0
            };
            var context = new ValidationContext(detail);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(detail, context, results, true);
            Assert.IsTrue(isValid);
            Assert.AreEqual(0, results.Count);
        }

        [TestMethod]
        public void CreateOrderDetailDto_InvalidObject_FailsValidation()
        {
            var detail = new CreateOrderDetailDto
            {
                ProductId = 0,
                UnitPrice = -1,
                Qty = 0,
                Discount = -1
            };
            var context = new ValidationContext(detail);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(detail, context, results, true);
            Assert.IsFalse(isValid);
            Assert.IsTrue(results.Count > 0);
        }
    }
}
