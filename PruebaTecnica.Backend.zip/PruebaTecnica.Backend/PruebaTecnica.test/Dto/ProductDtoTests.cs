using Microsoft.VisualStudio.TestTools.UnitTesting;
using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Tests.DTOs
{
    [TestClass]
    public class ProductDtoTests
    {
        [TestMethod]
        public void Constructor_SetsProperties()
        {
            var dto = new ProductDto(1, "Producto 1");
            Assert.AreEqual(1, dto.ProductId);
            Assert.AreEqual("Producto 1", dto.ProductName);
        }

        [TestMethod]
        public void Equality_SameValues_ReturnsTrue()
        {
            var dto1 = new ProductDto(1, "Producto 1");
            var dto2 = new ProductDto(1, "Producto 1");
            Assert.AreEqual(dto1, dto2);
            Assert.IsTrue(dto1 == dto2);
        }

        [TestMethod]
        public void Equality_DifferentValues_ReturnsFalse()
        {
            var dto1 = new ProductDto(1, "Producto 1");
            var dto2 = new ProductDto(2, "Producto 2");
            Assert.AreNotEqual(dto1, dto2);
            Assert.IsTrue(dto1 != dto2);
        }

        [TestMethod]
        public void ToString_ReturnsExpectedFormat()
        {
            var dto = new ProductDto(1, "Producto 1");
            var str = dto.ToString();
            Assert.IsTrue(str.Contains("ProductId = 1"));
            Assert.IsTrue(str.Contains("ProductName = Producto 1"));
        }
    }
}
