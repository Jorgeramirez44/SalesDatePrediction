using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Tests.DTOs
{
    [TestClass]
    public class PredictionItemDtoTests
    {
        [TestMethod]
        public void Constructor_SetsProperties()
        {
            var lastOrder = new DateTime(2024, 5, 1);
            var nextOrder = new DateTime(2024, 6, 1);
            var dto = new PredictionItemDto(
                10,
                "Cliente 1",
                lastOrder,
                nextOrder,
                5,
                12.5
            );
            Assert.AreEqual(10, dto.CustomerId);
            Assert.AreEqual("Cliente 1", dto.CustomerName);
            Assert.AreEqual(lastOrder, dto.LastOrderDate);
            Assert.AreEqual(nextOrder, dto.NextPredictedOrder);
            Assert.AreEqual(5, dto.OrdersCount);
            Assert.AreEqual(12.5, dto.AvgDaysBetweenOrders);
        }

        [TestMethod]
        public void Equality_SameValues_ReturnsTrue()
        {
            var date1 = new DateTime(2024, 5, 1);
            var date2 = new DateTime(2024, 6, 1);
            var dto1 = new PredictionItemDto(1, "A", date1, date2, 2, 10.0);
            var dto2 = new PredictionItemDto(1, "A", date1, date2, 2, 10.0);
            Assert.AreEqual(dto1, dto2);
            Assert.IsTrue(dto1 == dto2);
        }

        [TestMethod]
        public void Equality_DifferentValues_ReturnsFalse()
        {
            var dto1 = new PredictionItemDto(1, "A", null, null, 2, 10.0);
            var dto2 = new PredictionItemDto(2, "B", null, null, 3, 20.0);
            Assert.AreNotEqual(dto1, dto2);
            Assert.IsTrue(dto1 != dto2);
        }

        [TestMethod]
        public void ToString_ReturnsExpectedFormat()
        {
            var dto = new PredictionItemDto(1, "Cliente", null, null, 2, 10.0);
            var str = dto.ToString();
            Assert.IsTrue(str.Contains("CustomerId = 1"));
            Assert.IsTrue(str.Contains("CustomerName = Cliente"));
            Assert.IsTrue(str.Contains("OrdersCount = 2"));
            Assert.IsTrue(str.Contains("AvgDaysBetweenOrders = 10"));
        }
    }
}

