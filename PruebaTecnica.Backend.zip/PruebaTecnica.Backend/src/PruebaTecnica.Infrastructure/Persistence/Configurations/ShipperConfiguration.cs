
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.Persistence.Configurations;

public class ShipperConfiguration : IEntityTypeConfiguration<Shipper>
{
    public void Configure(EntityTypeBuilder<Shipper> builder)
    {
        builder.ToTable("Shippers", schema: "Sales");
        builder.HasKey(s => s.ShipperId).HasName("PK_Shippers");
        builder.Property(s => s.ShipperId).HasColumnName("shipperid");
        builder.Property(s => s.CompanyName).HasMaxLength(40).HasColumnName("companyname");
        builder.Property(s => s.Phone).HasMaxLength(24).HasColumnName("phone");
    }
}
