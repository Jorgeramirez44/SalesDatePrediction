
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.Persistence.Configurations;

public class EmployeeConfiguration : IEntityTypeConfiguration<Employee>
{
    public void Configure(EntityTypeBuilder<Employee> builder)
    {
        builder.ToTable("Employees", schema: "HR");
        builder.HasKey(e => e.EmpId).HasName("PK_Employees");
        builder.Property(e => e.EmpId).HasColumnName("empid");
        builder.Property(e => e.LastName).HasMaxLength(20).HasColumnName("lastname");
        builder.Property(e => e.FirstName).HasMaxLength(10).HasColumnName("firstname");
        builder.Property(e => e.Title).HasMaxLength(30).HasColumnName("title");
        builder.Property(e => e.TitleOfCourtesy).HasMaxLength(25).HasColumnName("titleofcourtesy");
        builder.Property(e => e.BirthDate).HasColumnName("birthdate");
        builder.Property(e => e.HireDate).HasColumnName("hiredate");
        builder.Property(e => e.Address).HasMaxLength(60).HasColumnName("address");
        builder.Property(e => e.City).HasMaxLength(15).HasColumnName("city");
        builder.Property(e => e.Region).HasMaxLength(15).HasColumnName("region");
        builder.Property(e => e.PostalCode).HasMaxLength(10).HasColumnName("postalcode");
        builder.Property(e => e.Country).HasMaxLength(15).HasColumnName("country");
        builder.Property(e => e.Phone).HasMaxLength(24).HasColumnName("phone");
        builder.Property(e => e.MgrId).HasColumnName("mgrid");
    }
}
