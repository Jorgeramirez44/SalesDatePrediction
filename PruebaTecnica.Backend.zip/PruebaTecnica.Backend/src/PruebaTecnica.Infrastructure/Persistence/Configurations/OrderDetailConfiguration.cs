
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.Persistence.Configurations;

public class OrderDetailConfiguration : IEntityTypeConfiguration<OrderDetail>
{
    public void Configure(EntityTypeBuilder<OrderDetail> builder)
    {
        builder.ToTable("OrderDetails", schema: "Sales");
        builder.HasKey(od => new { od.OrderId, od.ProductId }).HasName("PK_OrderDetails");
        builder.Property(od => od.OrderId).HasColumnName("orderid");
        builder.Property(od => od.ProductId).HasColumnName("productid");
        builder.Property(od => od.UnitPrice).HasColumnName("unitprice").HasColumnType("money");
        builder.Property(od => od.Qty).HasColumnName("qty");
        builder.Property(od => od.Discount).HasColumnName("discount");

        builder.HasOne(od => od.Order).WithMany(o => o.Details).HasForeignKey(od => od.OrderId).HasConstraintName("FK_OrderDetails_Orders");
        builder.HasOne(od => od.Product).WithMany().HasForeignKey(od => od.ProductId).HasConstraintName("FK_OrderDetails_Products");
    }
}
