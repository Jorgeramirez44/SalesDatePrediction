using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.Persistence.Configurations;

public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.ToTable("Orders", schema: "Sales");

        builder.HasKey(o => o.OrderId).HasName("PK_Orders");

        builder.Property(o => o.OrderId).HasColumnName("orderid");
        builder.Property(o => o.CustId).HasColumnName("custid");
        builder.Property(o => o.EmpId).HasColumnName("empid");
        builder.Property(o => o.OrderDate).HasColumnName("orderdate");
        builder.Property(o => o.RequiredDate).HasColumnName("requireddate");
        builder.Property(o => o.ShippedDate).HasColumnName("shippeddate");
        builder.Property(o => o.ShipperId).HasColumnName("shipperid");
        builder.Property(o => o.Freight).HasColumnName("freight").HasColumnType("money");
        builder.Property(o => o.ShipName).HasMaxLength(40).HasColumnName("shipname");
        builder.Property(o => o.ShipAddress).HasMaxLength(60).HasColumnName("shipaddress");
        builder.Property(o => o.ShipCity).HasMaxLength(15).HasColumnName("shipcity");
        builder.Property(o => o.ShipRegion).HasMaxLength(15).HasColumnName("shipregion");
        builder.Property(o => o.ShipPostalCode).HasMaxLength(10).HasColumnName("shippostalcode");
        builder.Property(o => o.ShipCountry).HasMaxLength(15).HasColumnName("shipcountry");
        
        builder.HasOne(o => o.Customer)
               .WithMany(c => c.Orders)
               .HasForeignKey(o => o.CustId)
               .HasConstraintName("FK_Orders_Customers");

        
        builder.HasOne(o => o.Employee)
               .WithMany() 
               .HasForeignKey(o => o.EmpId)
               .HasConstraintName("FK_Orders_Employees");

        
        builder.HasOne(o => o.Shipper)
               .WithMany() 
               .HasForeignKey(o => o.ShipperId)
               .HasConstraintName("FK_Orders_Shippers");
    }
}
