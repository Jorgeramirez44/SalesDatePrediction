
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.Persistence.Configurations;

public class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("Products", schema: "Production");
        builder.HasKey(p => p.ProductId).HasName("PK_Products");
        builder.Property(p => p.ProductId).HasColumnName("productid");
        builder.Property(p => p.ProductName).HasMaxLength(40).HasColumnName("productname");
        builder.Property(p => p.SupplierId).HasColumnName("supplierid");
        builder.Property(p => p.CategoryId).HasColumnName("categoryid");
        builder.Property(p => p.UnitPrice).HasColumnName("unitprice").HasColumnType("money");
        builder.Property(p => p.Discontinued).HasColumnName("discontinued");
    }
}
