
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using PruebaTecnica.Domain.Entities;

namespace PruebaTecnica.Infrastructure.Persistence.Configurations;

public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.ToTable("Customers", schema: "Sales");
        builder.HasKey(c => c.CustId).HasName("PK_Customers");
        builder.Property(c => c.CustId).HasColumnName("custid");
        builder.Property(c => c.CompanyName).HasMaxLength(40).HasColumnName("companyname");
        builder.Property(c => c.ContactName).HasMaxLength(30).HasColumnName("contactname");
        builder.Property(c => c.ContactTitle).HasMaxLength(30).HasColumnName("contacttitle");
        builder.Property(c => c.Address).HasMaxLength(60).HasColumnName("address");
        builder.Property(c => c.City).HasMaxLength(15).HasColumnName("city");
        builder.Property(c => c.Region).HasMaxLength(15).HasColumnName("region");
        builder.Property(c => c.PostalCode).HasMaxLength(10).HasColumnName("postalcode");
        builder.Property(c => c.Country).HasMaxLength(15).HasColumnName("country");
        builder.Property(c => c.Phone).HasMaxLength(24).HasColumnName("phone");
        builder.Property(c => c.Fax).HasMaxLength(24).HasColumnName("fax");
        builder.HasMany(c => c.Orders).WithOne(o => o.Customer).HasForeignKey(o => o.CustId).HasConstraintName("FK_Orders_Customers");
    }
}
