
using PruebaTecnica.Application.Common;
using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Interfaces;

public interface IPredictionService
{
    Task<PagedResult<PredictionItemDto>> GetCustomerPredictionsAsync(string? search, int pageNumber, int pageSize, string? sort);
}
