
using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Interfaces;

public interface ILookupService
{
    Task<IReadOnlyList<EmployeeDto>> GetEmployeesAsync();
    Task<IReadOnlyList<ShipperDto>> GetShippersAsync();
    Task<IReadOnlyList<ProductDto>> GetProductsAsync();
    Task<IReadOnlyList<OrderSummaryDto>> GetOrdersByCustomerAsync(int customerId);
}
