
using PruebaTecnica.Application.DTOs;

namespace PruebaTecnica.Application.Interfaces;

public interface IOrderService
{
    Task<int> CreateOrderWithSingleDetailAsync(CreateOrderRequestDto request);
}
