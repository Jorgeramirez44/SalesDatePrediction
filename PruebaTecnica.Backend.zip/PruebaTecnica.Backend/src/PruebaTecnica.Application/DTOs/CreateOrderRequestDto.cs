
using System.ComponentModel.DataAnnotations;

namespace PruebaTecnica.Application.DTOs;

public class CreateOrderRequestDto
{
    [Required]
    public int CustId { get; set; }

    [Required]
    public int EmpId { get; set; }

    [Required]
    public int ShipperId { get; set; }

    [Required]
    [MaxLength(40)]
    public string ShipName { get; set; } = string.Empty;

    [Required]
    [MaxLength(60)]
    public string ShipAddress { get; set; } = string.Empty;

    [Required]
    [MaxLength(15)]
    public string ShipCity { get; set; } = string.Empty;

    [MaxLength(15)]
    public string? ShipRegion { get; set; }

    [MaxLength(10)]
    public string? ShipPostalCode { get; set; }

    [Required]
    [MaxLength(15)]
    public string ShipCountry { get; set; } = string.Empty;

    [Required]
    public DateTime OrderDate { get; set; }

    [Required]
    public DateTime RequiredDate { get; set; }

    public DateTime? ShippedDate { get; set; }

    [Range(0, double.MaxValue)]
    public decimal Freight { get; set; }

    [Required]
    public CreateOrderDetailDto Detail { get; set; } = new();
}

public class CreateOrderDetailDto
{
    [Required]
    public int ProductId { get; set; }

    [Range(0, double.MaxValue)]
    public decimal UnitPrice { get; set; }

    [Range(1, int.MaxValue)]
    public int Qty { get; set; }

    [Range(0, 1)]
    public decimal Discount { get; set; }
}
