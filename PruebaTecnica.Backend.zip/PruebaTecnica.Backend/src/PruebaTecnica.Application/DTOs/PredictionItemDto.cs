
namespace PruebaTecnica.Application.DTOs;

public record PredictionItemDto(
    int CustomerId,
    string CustomerName,
    DateTime? LastOrderDate,
    DateTime? NextPredictedOrder,
    int OrdersCount,
    double? AvgDaysBetweenOrders
);
