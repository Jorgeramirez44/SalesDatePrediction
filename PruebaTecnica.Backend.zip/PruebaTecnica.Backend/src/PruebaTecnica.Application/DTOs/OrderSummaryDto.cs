
namespace PruebaTecnica.Application.DTOs;

public record OrderSummaryDto(
    int OrderId,
    DateTime RequiredDate,
    DateTime? ShippedDate,
    string ShipName,
    string ShipAddress,
    string ShipCity
);
