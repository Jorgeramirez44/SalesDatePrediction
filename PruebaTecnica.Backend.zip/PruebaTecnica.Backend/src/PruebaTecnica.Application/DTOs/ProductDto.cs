
namespace PruebaTecnica.Application.DTOs;

public record ProductDto(int ProductId, string ProductName);
