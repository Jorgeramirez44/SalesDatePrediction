
namespace PruebaTecnica.Application.DTOs;

public record ShipperDto(int ShipperId, string CompanyName);
