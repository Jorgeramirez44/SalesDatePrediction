
namespace PruebaTecnica.Application.DTOs;

public record EmployeeDto(int EmpId, string FullName);
