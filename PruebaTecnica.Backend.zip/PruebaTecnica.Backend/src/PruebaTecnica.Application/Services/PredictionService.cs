
using Microsoft.EntityFrameworkCore;
using PruebaTecnica.Application.Common;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;
using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Infrastructure.Persistence;

namespace PruebaTecnica.Application.Services;

public class PredictionService : IPredictionService
{
    private readonly PruebaTecnicaDbContext _db;
    public PredictionService(PruebaTecnicaDbContext db) => _db = db;

    public async Task<PagedResult<PredictionItemDto>> GetCustomerPredictionsAsync(string? search, int pageNumber, int pageSize, string? sort)
    {
        if (pageNumber < 1) pageNumber = 1;
        if (pageSize < 1 || pageSize > 200) pageSize = 20;

        var query = _db.Customers.AsNoTracking().Include(c => c.Orders).AsQueryable();
        if (!string.IsNullOrWhiteSpace(search))
        {
            search = search.Trim();
            query = query.Where(c => c.CompanyName.Contains(search));
        }

        // Materialize minimal data to memory for calculation
        var customers = await query
            .Select(c => new { c.CustId, c.CompanyName, Orders = c.Orders.Select(o => o.OrderDate).ToList() })
            .ToListAsync();

        var computed = customers.Select(c =>
        {
            var dates = c.Orders.OrderBy(d => d).ToList();
            DateTime? last = dates.Count > 0 ? dates[^1] : null;
            double? avg = null;
            if (dates.Count >= 2)
            {
                var diffs = new List<double>();
                for (int i = 1; i < dates.Count; i++)
                {
                    diffs.Add((dates[i] - dates[i - 1]).TotalDays);
                }
                avg = diffs.Average();
            }
            DateTime? next = (last.HasValue && avg.HasValue) ? last.Value.AddDays(avg.Value) : (DateTime?)null;
            return new PredictionItemDto(c.CustId, c.CompanyName, last, next, dates.Count, avg);
        });

        // Sorting
        IOrderedEnumerable<PredictionItemDto> ordered;
        switch ((sort ?? "CustomerName:asc").ToLowerInvariant())
        {
            case "customername:desc": ordered = computed.OrderByDescending(x => x.CustomerName); break;
            case "lastorderdate:asc": ordered = computed.OrderBy(x => x.LastOrderDate); break;
            case "lastorderdate:desc": ordered = computed.OrderByDescending(x => x.LastOrderDate); break;
            case "nextpredictedorder:asc": ordered = computed.OrderBy(x => x.NextPredictedOrder); break;
            case "nextpredictedorder:desc": ordered = computed.OrderByDescending(x => x.NextPredictedOrder); break;
            case "orderscount:asc": ordered = computed.OrderBy(x => x.OrdersCount); break;
            case "orderscount:desc": ordered = computed.OrderByDescending(x => x.OrdersCount); break;
            case "avgdaysbetweenorders:asc": ordered = computed.OrderBy(x => x.AvgDaysBetweenOrders); break;
            case "avgdaysbetweenorders:desc": ordered = computed.OrderByDescending(x => x.AvgDaysBetweenOrders); break;
            default: ordered = computed.OrderByDescending(x => x.LastOrderDate); break;
        }

        var total = ordered.Count();
        var items = ordered.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToList();
        return new PagedResult<PredictionItemDto>(items, total, pageNumber, pageSize);
    }
}
