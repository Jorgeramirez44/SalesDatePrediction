
using Microsoft.EntityFrameworkCore;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;
using PruebaTecnica.Infrastructure.Persistence;

namespace PruebaTecnica.Application.Services;

public class LookupService : ILookupService
{
    private readonly PruebaTecnicaDbContext _db;
    public LookupService(PruebaTecnicaDbContext db) => _db = db;


    public async Task<IReadOnlyList<EmployeeDto>> GetEmployeesAsync()
        => await _db.Employees.AsNoTracking()
            .OrderBy(e => e.LastName).ThenBy(e => e.FirstName)
            .Select(e => new EmployeeDto(e.EmpId, e.FirstName + " " + e.LastName))
            .ToListAsync();
    public async Task<IReadOnlyList<ProductDto>> GetProductsAsync()
        => await _db.Products.AsNoTracking()
            .OrderBy(p => p.ProductName)
            .Select(p => new ProductDto(p.ProductId, p.ProductName))
            .ToListAsync();


    public async Task<IReadOnlyList<ShipperDto>> GetShippersAsync()
        => await _db.Shippers.AsNoTracking()
            .OrderBy(s => s.CompanyName)
            .Select(s => new ShipperDto(s.ShipperId, s.CompanyName))
            .ToListAsync();


    public async Task<IReadOnlyList<OrderSummaryDto>> GetOrdersByCustomerAsync(int customerId)
        => await _db.Orders.AsNoTracking()
            .Where(o => o.CustId == customerId)
            .OrderByDescending(o => o.RequiredDate)
            .Select(o => new OrderSummaryDto(
                o.OrderId,
                o.RequiredDate,
                o.ShippedDate,
                o.ShipName,
                o.ShipAddress,
                o.ShipCity
            )).ToListAsync();
}
