
using Microsoft.EntityFrameworkCore;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;
using PruebaTecnica.Domain.Entities;
using PruebaTecnica.Infrastructure.Persistence;

namespace PruebaTecnica.Application.Services;

public class OrderService : IOrderService
{
    private readonly PruebaTecnicaDbContext _db;
    public OrderService(PruebaTecnicaDbContext db) => _db = db;

    public async Task<int> CreateOrderWithSingleDetailAsync(CreateOrderRequestDto request)
    {
        // Optional: basic referential checks
        var customerExists = await _db.Customers.AnyAsync(c => c.CustId == request.CustId);
        if (!customerExists) throw new ArgumentException($"Customer {request.CustId} not found");
        var employeeExists = await _db.Employees.AnyAsync(e => e.EmpId == request.EmpId);
        if (!employeeExists) throw new ArgumentException($"Employee {request.EmpId} not found");
        var shipperExists = await _db.Shippers.AnyAsync(s => s.ShipperId == request.ShipperId);
        if (!shipperExists) throw new ArgumentException($"Shipper {request.ShipperId} not found");
        var productExists = await _db.Products.AnyAsync(p => p.ProductId == request.Detail.ProductId);
        if (!productExists) throw new ArgumentException($"Product {request.Detail.ProductId} not found");

        var order = new Order
        {
            CustId = request.CustId,
            EmpId = request.EmpId,
            OrderDate = request.OrderDate,
            RequiredDate = request.RequiredDate,
            ShippedDate = request.ShippedDate,
            ShipperId = request.ShipperId,
            Freight = request.Freight,
            ShipName = request.ShipName,
            ShipAddress = request.ShipAddress,
            ShipCity = request.ShipCity,
            ShipRegion = request.ShipRegion,
            ShipPostalCode = request.ShipPostalCode,
            ShipCountry = request.ShipCountry,
            Details = new List<OrderDetail>
            {
                new OrderDetail
                {
                    ProductId = request.Detail.ProductId,
                    UnitPrice = request.Detail.UnitPrice,
                    Qty = (short)request.Detail.Qty,
                    Discount = request.Detail.Discount
                }
            }
        };

        _db.Orders.Add(order);
        await _db.SaveChangesAsync();
        return order.OrderId;
    }
}
