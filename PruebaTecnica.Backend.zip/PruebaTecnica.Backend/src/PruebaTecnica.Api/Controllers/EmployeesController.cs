
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmployeesController : ControllerBase
{
    private readonly ILookupService _lookup;
    public EmployeesController(ILookupService lookup) => _lookup = lookup;

    /// <summary>
    /// Listar todos los empleados (EmpId, FullName)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var employees = await _lookup.GetEmployeesAsync();
        return Ok(employees);
    }
}
