
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly ILookupService _lookup;
    public ProductsController(ILookupService lookup) => _lookup = lookup;

    /// <summary>
    /// Listar todos los productos
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var products = await _lookup.GetProductsAsync();
        return Ok(products);
    }
}
