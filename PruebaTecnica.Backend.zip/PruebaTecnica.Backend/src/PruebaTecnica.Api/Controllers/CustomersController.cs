
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CustomersController : ControllerBase
{
    private readonly ILookupService _lookup;
    public CustomersController(ILookupService lookup) => _lookup = lookup;

    /// <summary>
    /// Listar órdenes por cliente (OrderId, RequiredDate, ShippedDate, ShipName, ShipAddress, ShipCity)
    /// </summary>
    [HttpGet("{customerId:int}/orders")]
    public async Task<IActionResult> GetOrdersByCustomer(int customerId)
    {
        var orders = await _lookup.GetOrdersByCustomerAsync(customerId);
        return Ok(orders);
    }
}
