
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.DTOs;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly IOrderService _orderService;
    public OrdersController(IOrderService orderService) => _orderService = orderService;

    /// <summary>
    /// Crear una nueva orden (con un solo detalle)
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateOrderRequestDto request)
    {
        if (!ModelState.IsValid)
            return ValidationProblem(ModelState);

        var newId = await _orderService.CreateOrderWithSingleDetailAsync(request);
        return CreatedAtAction(nameof(Create), new { id = newId }, new { orderId = newId });
    }
}
