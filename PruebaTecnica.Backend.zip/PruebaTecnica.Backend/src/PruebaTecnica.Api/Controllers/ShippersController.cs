
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ShippersController : ControllerBase
{
    private readonly ILookupService _lookup;
    public ShippersController(ILookupService lookup) => _lookup = lookup;

    /// <summary>
    /// Listar todos los transportistas (Shippers)
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var shippers = await _lookup.GetShippersAsync();
        return Ok(shippers);
    }
}
