
using Microsoft.AspNetCore.Mvc;
using PruebaTecnica.Application.Interfaces;

namespace PruebaTecnica.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PredictionsController : ControllerBase
{
    private readonly IPredictionService _predictionService;
    public PredictionsController(IPredictionService predictionService) => _predictionService = predictionService;

    /// <summary>
    /// Listar clientes con fecha de última orden y fecha de posible siguiente orden.
    /// Soporta búsqueda por nombre de cliente, ordenamiento y paginación.
    /// </summary>
    [HttpGet("customers")]
    public async Task<IActionResult> GetCustomerPredictions(
        [FromQuery] string? search,
        [FromQuery] int pageNumber = 1,
        [FromQuery] int pageSize = 20,
        [FromQuery] string? sort = null)
    {
        var result = await _predictionService.GetCustomerPredictionsAsync(search, pageNumber, pageSize, sort);
        return Ok(result);
    }
}
